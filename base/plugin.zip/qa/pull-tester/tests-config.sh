#!/bin/bash
# Copyright (c) 2010-2019 Nur1Labs.Ltd
# Distributed under the MIT software license, see the accompanying
# file COPYING or http://www.opensource.org/licenses/mit-license.php.

BUILDDIR="/home/mini/mubdi"
EXEEXT=".exe"

# These will turn into comments if they were disabled when configuring.
ENABLE_MUBDID=1

REAL_MUBDID="$BUILDDIR/src/mubdid${EXEEXT}"

